# neighborhoodOS — Brand, Voice & Design System
*A working reference for everyone who writes, designs, or builds for neighborhoodos.org.*

Version 1.0 · Last updated April 2026

---

## 0. How to use this document

This is a working reference, not a rulebook. When something here gets in the way of clarity or kindness, ignore it and tell us why — the doc will get better.

If you're in a hurry:
- **Voice in one line:** *Curious, plainspoken, useful. Like a smart neighbor who actually shows up.*
- **Look in one line:** *Warm paper, terracotta and ochre, a serif that thinks and a sans that gets out of the way.*
- **Don't:** Be slick, performative, or vague. We earn trust by being specific.

---

## 1. What we are

**neighborhoodOS is the operating layer for neighborhoods.** We turn the messy, real-world data of a place — who lives there, what's happening, what's working, what isn't — into something a community organizer or neighbor can actually use.

We are not a social network. We are not a city dashboard. We are infrastructure for the block, the building, the street.

**Who we serve, in order:**
1. **Neighborhood organizers** — block captains, mutual aid leads, tenant union folks, PTA presidents.
2. **Neighbors** — the people who live there and want to help, complain, or know.
3. **Allies** — local nonprofits, small civic teams, researchers who treat communities as partners rather than subjects.

### Mission
To make every neighborhood legible to itself.

### What we believe
- A neighborhood already knows things its city doesn't. Our job is to help it write them down.
- Data without consent is surveillance. Data without context is noise.
- The best civic tool is one a busy person can use on their phone in a parking lot.
- Software should defer to the place it serves. Quiet, sturdy, slightly handmade.

### What we are not
- We are not Nextdoor. We are not a feed.
- We are not a dashboard for City Hall to watch residents.
- We are not a startup pretending to be a community.

---

## 2. Voice & Tone

### The voice, in one paragraph

We sound like **a curious neighbor explaining something they actually care about.** The reference is Richard Feynman: smart but never showing it off, generous with detail, willing to say "I don't know," allergic to jargon. We use small words to carry big ideas. We are warm without being precious, plain without being dull.

### Six principles

1. **Be specific.** "Trash pickup is late on Wednesdays" beats "operational inefficiencies in waste management."
2. **Show your work.** If we made a number, say how. If we don't know, say so.
3. **Use the smallest word that fits.** "Use," not "utilize." "Help," not "facilitate."
4. **Ask first.** Questions invite. Statements close. Headlines are often better as questions.
5. **No civic theater.** Skip "empowering," "synergies," "stakeholders," "ecosystem." We're not running for office.
6. **Earnest, not solemn.** It's okay to be funny. It's not okay to be cute.

### Tone, by surface

| Surface | Lean | Example |
|---|---|---|
| Marketing site | Curious, inviting | *"What if your block knew what your block knew?"* |
| Product UI | Calm, exact | *"Saved. 41 households on this list."* |
| Empty states | Warm, slightly funny | *"Nothing here yet. That's okay — most things start that way."* |
| Errors | Honest, brief, useful | *"We couldn't reach the server. Try again, or open the local cache."* |
| Data labels | Literal, no flourish | *"Households reporting noise complaints, last 30 days."* |
| Email | Like a real person wrote it | *"Hey — quick note about the August outage. Here's what happened…"* |
| Legal / Privacy | Plain English first, lawyer second | *"We don't sell your data. Here's the long version."* |

### Do / Don't

✅ **Do**
- *"5,200 neighbors got food this month — about one in nine households on the East Side."*
- *"This is rough. We're guessing from three sources. Tell us what's wrong."*
- *"Block captains: if you've got 10 minutes, this saves you 2 hours."*
- *"We don't know yet. Here's what we'd need to find out."*

❌ **Don't**
- *"Empowering communities through data-driven insights at scale."*
- *"Unlock the power of your neighborhood."*
- *"Our AI-powered platform leverages cutting-edge technology…"*
- *"We're on a mission to revolutionize civic engagement."*

### Banned words & phrases

*leverage, unlock, empower, ecosystem, stakeholder, robust, seamless, holistic, end-to-end, mission-critical, world-class, revolutionize, disrupt, game-changer, solution (as a noun for software)*

If you catch one in a draft, ask: what would Feynman say instead? Usually it's a verb.

### Naming things in product

- **Action verbs over nouns.** "Add a neighbor," not "Neighbor management."
- **Use the local word.** "Block," "stoop," "building," "corner" — match what people actually call the thing.
- **Numbers are people.** "41 neighbors," not "41 records." "127 households," not "127 entries."

---

## 3. Logo

The wordmark is **neighborhoodOS** set in Fraunces Semibold, with **OS** in capitals and a slight optical kerning. The lowercase "n" anchors it; the "OS" gives it backbone.

### Construction
- The "OS" sits at the same x-height as the lowercase letters in capitals (never lowercase, never small caps).
- Letterspacing: tight but not crashing. Optical, not metric.
- A single dot — the **"o" of OS** — can be lifted out as a standalone mark when space is tight (favicons, app icons, profile avatars).

### Clear space
Leave at least the height of a lowercase "o" on every side. More is better.

### Minimum sizes
- Web: 96px wide minimum for the full wordmark.
- Print: 18mm wide minimum.
- Below that, use the dot mark.

### Color use
- **Primary:** Ink (`#1F1A17`) on Paper (`#F5EFE6`).
- **Reverse:** Paper on Ink, or Paper on Terracotta.
- Never on photographs without a paper card behind it.
- Never in gradient. Never with a drop shadow. Never outlined.

### Don'ts
- Don't stretch, skew, or rotate.
- Don't recolor the dot to match a partner brand.
- Don't add a tagline locked to the mark. Taglines live separately.
- Don't put it inside a circle, square, or "badge."

---

## 4. Typography

We use three families. That's the budget.

### The set

| Role | Family | Why |
|---|---|---|
| **Display** | Fraunces (var.) | Warm, slightly literary serif. Carries headlines and editorial moments. |
| **Text** | Inter Tight | Quiet, legible workhorse. Runs the UI. |
| **Mono** | JetBrains Mono | Numbers, data, code, anything that needs to feel exact. |

All three are open-source and free to embed.

### Type scale (web, 16px base)

| Token | Size / Line | Family | Use |
|---|---|---|---|
| `display-xl` | 72 / 76 | Fraunces 400 | Hero / cover |
| `display-lg` | 56 / 60 | Fraunces 400 | Section opener |
| `display-md` | 40 / 46 | Fraunces 500 | Page title |
| `headline` | 28 / 34 | Fraunces 500 | Card title, dialog |
| `title` | 20 / 26 | Inter Tight 600 | Subhead, table header |
| `body-lg` | 18 / 28 | Inter Tight 400 | Long-form reading |
| `body` | 16 / 24 | Inter Tight 400 | Default UI |
| `body-sm` | 14 / 20 | Inter Tight 400 | Secondary, captions |
| `label` | 12 / 16 | Inter Tight 600 (tracked +2%) | Form labels, eyebrows |
| `mono-lg` | 32 / 36 | JetBrains Mono 500 | Big numbers (dashboards) |
| `mono` | 14 / 20 | JetBrains Mono 400 | Inline data, IDs |

### Typographic principles
- **Serifs do the thinking, sans does the working.** Fraunces is for moments. Inter Tight is for everything else.
- **Big numbers are typography.** When we show a count, set it in JetBrains Mono with optical sizing. The number is the design.
- **Italic is a quiet voice.** Use Fraunces italic for asides, captions, and the occasional pull quote.
- **Set tightly, lead generously.** Tight tracking, generous line-height. Let the page breathe.
- **Hyphenate long-form prose.** `text-wrap: pretty` on headlines. `hyphens: auto` on body.

---

## 5. Color

A warm, paper-and-clay palette. Most of the system is neutral; the accents do real work.

### The palette

#### Neutrals
| Token | Hex | OKLCH | Use |
|---|---|---|---|
| `paper` | `#F5EFE6` | `oklch(95% 0.012 80)` | Default background |
| `paper-2` | `#EDE5D6` | `oklch(91% 0.018 82)` | Cards on paper |
| `paper-3` | `#E2D8C3` | `oklch(86% 0.025 84)` | Dividers, hairlines |
| `ink` | `#1F1A17` | `oklch(20% 0.008 50)` | Body text, primary |
| `ink-2` | `#3A332D` | `oklch(30% 0.010 50)` | Secondary text |
| `ink-3` | `#7A6F66` | `oklch(53% 0.012 60)` | Tertiary, captions |

#### Accents
| Token | Hex | OKLCH | Use |
|---|---|---|---|
| `terracotta` | `#C2553A` | `oklch(58% 0.140 38)` | Primary action, brand voice |
| `terracotta-deep` | `#8E3A26` | `oklch(42% 0.130 36)` | Hover, active text on paper |
| `ochre` | `#D9A441` | `oklch(74% 0.130 75)` | Highlights, data positive |
| `moss` | `#5C7A4E` | `oklch(52% 0.080 130)` | Success, parks, "good" data |
| `dusk` | `#3F4A6B` | `oklch(40% 0.060 260)` | Info, links in body |
| `brick` | `#8B2E1F` | `oklch(38% 0.130 32)` | Critical / warning |

Accents share a chroma band of roughly 0.06–0.14 at lightness 0.40–0.74 — they look like they came from the same place because they did.

### Color principles
- **Paper is the default.** Most surfaces are `paper`. Cards lift to `paper-2`. White (`#FFFFFF`) appears nowhere on the marketing site and only inside dense data tables in product.
- **One accent per surface.** Never two accents shouting at each other on the same screen. Pick the one that matches the meaning.
- **Color carries meaning, not decoration.** Terracotta = action. Moss = good. Brick = bad. Ochre = noteworthy. Dusk = link/info.
- **No gradients in the UI.** Atmosphere comes from paper textures and warm neutrals, not gradient fills.

### Dark mode (Lantern)
| Token | Hex | OKLCH |
|---|---|---|
| `lantern-bg` | `#1A1714` | `oklch(17% 0.008 60)` |
| `lantern-bg-2` | `#262220` | `oklch(22% 0.010 60)` |
| `lantern-paper` | `#F0E7D7` | `oklch(92% 0.018 82)` (text) |
| `terracotta-lit` | `#E07A5F` | `oklch(70% 0.130 38)` |

Dark mode is a lantern, not a void: warm, slightly amber, never neutral gray.

### Accessibility
- Body text on `paper` must hit **WCAG AA (4.5:1)**. `ink` on `paper` is 13.4:1. ✓
- `terracotta` on `paper` is **4.6:1** — fine for ≥18px or bold. For body links use `terracotta-deep` (7.1:1).
- Never rely on color alone. Status uses an icon and a label, always.

---

## 6. Iconography & Illustration

### Icons
- **Stroke:** 1.5px, rounded caps, rounded joins. 24px grid.
- **Style:** Geometric, slightly soft. Closer to Phosphor or Iconoir than Feather.
- **Single weight only.** No filled variants in the UI; filled is reserved for active/selected states.
- **One per concept.** If a screen has both a "house" and a "home" icon, we picked wrong.

### Illustration: "Hand-set"
Our illustration style is **hand-set**: shapes that feel like they were arranged by hand on a paper field. Think:
- Block-printed posters from a community center
- Sister Corita Kent's screen-printed work
- 1970s utopian planning diagrams
- Risograph two-color overlays

Rules:
- Two to three colors max per illustration, all from the palette.
- Slight off-register: a 1–2px shift between color layers, like risograph misalignment.
- Visible texture: paper grain, halftone dots, or a subtle noise overlay.
- People are abstracted: silhouettes, no facial features, varied body shapes.
- Buildings are geometric primitives — rectangles, triangles, circles. Not architectural renderings.

What to avoid:
- Corporate vector "people-with-laptops" art.
- Glossy 3D renders.
- AI-generated illustration that smells like AI (extra fingers, melting text, uncanny lighting).
- Anything that looks like a stock illustration pack.

### Data visualization
- **Bars over pies.** Always.
- **Color sparingly.** A chart with one terracotta bar against six `ink-3` bars beats a rainbow.
- **Label directly.** Legends are the last resort.
- **Show the zero.** Truncated y-axes lie.
- **Annotate.** A chart with a sentence beneath it telling you what to notice is worth ten without.

---

## 7. Photography & Imagery

### Direction
Real places, real people, real light. Documentary, not lifestyle.

**Yes:**
- Block parties at golden hour.
- A community fridge on a stoop.
- A hand-lettered sign taped to a lamppost.
- An organizer at a kitchen table with a laptop and a clipboard.
- Empty streets, full of texture: brick, chain-link, sidewalk chalk.

**No:**
- Stock smiling-people-pointing-at-screens.
- Aerial drone shots of cities.
- Anything shot in a coworking space.
- Hands typing on a glowing laptop in a dark room.
- Fake "diversity" photos. Diversity is real or it isn't there.

### Treatment
- Slight warm shift in post (+5 temperature). Never cold.
- Grain is welcome. Crush the blacks slightly.
- Never desaturate to gray. If you don't want color, go duotone (paper + ink).

### Sourcing
Prefer photographers who live in the places we serve. Pay them. Credit them in alt text and on the site.

---

## 8. Layout & Grid

### Marketing
- **12-column grid**, 80px outer margin desktop, 24px mobile.
- **Asymmetry by default.** Headlines hang left, set ragged-right. Captions float in margins.
- **Wide line-length is okay** for editorial moments (up to 75ch), narrow (50–60ch) for body.
- **Negative space is structural**, not decorative. Let sections breathe.

### Product
- **8px base unit.** Everything is a multiple of 8 (or 4 for fine detail).
- **3-pane structure** for main app: nav (240px) · list (360px) · detail (fluid). Collapses gracefully.
- **Density is a feature.** Organizers manage hundreds of households on small laptops. Default to compact rows; let users loosen.

### Shadows
Almost none. Elevation is signaled by:
1. Background shift (`paper` → `paper-2`).
2. A 1px hairline in `paper-3`.
3. Occasionally, a long, soft shadow at 4% opacity for floating UI (menus, toasts).

No "card with drop shadow" by default. We are paper on paper.

### Corners
- **Cards:** 12px
- **Buttons / inputs:** 8px
- **Pills / tags:** fully rounded
- **Images:** 4px (just enough to not look raw)

---

## 9. Motion

Motion in neighborhoodOS is **considered, never decorative.** It clarifies, never entertains.

### Principles
- **Fast in, slow out.** Easing: `cubic-bezier(0.2, 0.8, 0.2, 1)`. Default duration 200ms; modal 320ms; page 480ms.
- **Honor `prefers-reduced-motion`.** Always.
- **Things come from where they came from.** A row that opens into a detail view should expand, not fade.
- **Numbers tick, they don't fly.** Counters animate value-by-value, never bounce.
- **Never spin a logo.** We're not a launch screen.

### Vocabulary
- **Lift:** 1px translate up, 200ms, on hover for actionable items.
- **Settle:** 8px translate up + opacity, on entrance.
- **Reveal:** clip-path expand, for inline content opening.
- **Pulse:** a slow 2s opacity breathe for "live" data labels.

---

## 10. Component Patterns

### Buttons
- **Primary:** `terracotta` background, `paper` text, 8px radius, 12px/24px padding. Hover: `terracotta-deep`.
- **Secondary:** `ink` 1px border, `ink` text, transparent background. Hover: `paper-2` fill.
- **Ghost:** No border, `ink-2` text. Underline on hover.
- **Destructive:** `brick` text on a `brick`-tinted paper, never a solid red button.

### Forms
- Labels above inputs, never inside (no floating labels).
- 1px hairline border in `paper-3`. Focus: 2px `terracotta` ring with 2px offset.
- Help text in `ink-3`, error text in `brick`.
- Required is implied; mark **optional** instead.

### Cards
- `paper-2` background on `paper`. 1px `paper-3` border. 12px radius.
- Title in `headline` (Fraunces), supporting text in `body` (Inter Tight).
- One primary action per card, top-right or bottom-right — pick one and hold it across the surface.

### Tables
- No vertical rules.
- Horizontal hairlines in `paper-3`.
- Numeric columns right-aligned, in JetBrains Mono.
- Row hover in `paper-2`. Selection in `ochre` at 15% over the row.

### Navigation
- Top nav on marketing: paper bar, ink wordmark, ink-2 links, no underlines until hover.
- Side nav in product: `paper-2` rail, active item gets a 3px `terracotta` left bar and `ink` text.

### Empty states
Always three things: an honest sentence, a small hand-set illustration, and one clear next step.

> *"Nothing here yet. That's okay — most things start that way."*
> [Add your first block](#)

### Toasts
Bottom-left. `paper-2` with hairline. Auto-dismiss at 4s for info, sticky for errors. Never bottom-center; that's where browser UI lives.

---

## 11. Writing Examples

### Headlines (do)
- *What if your block knew what your block knew?*
- *Built for the people who already do the work.*
- *The neighborhood, in one place. With its permission.*
- *Run a block. Run a building. Run a borough.*
- *Ask better questions about where you live.*

### Headlines (don't)
- *The Future of Community Engagement, Reimagined.*
- *AI-Powered Neighborhood Intelligence.*
- *Unlock Hyperlocal Insights.*

### Microcopy

| Surface | Copy |
|---|---|
| Sign-up button | *Get started — it's free for organizers* |
| Empty list | *No neighbors here yet. Add the first one, or import from a CSV.* |
| Loading | *Pulling fresh numbers…* (not "Loading…" if we can name what we're loading) |
| Save success | *Saved.* |
| Save failure | *Couldn't save that. Your draft is safe — try again?* |
| 404 | *We don't have a page for that. Maybe try the [map](#) or the [index](#)?* |
| Cookie banner | *We use cookies to keep you signed in. That's it. [Details](#).* |

### A short product email

> Subject: A weird thing happened on Tuesday
>
> Hey —
>
> Tuesday afternoon, the dashboard was slow for about 40 minutes. If you tried to load a household list and got a spinner that wouldn't stop, that's why.
>
> Here's what happened: we'd just shipped a change to how we count active households, and the query we wrote was, technically, terrible. We rolled it back at 4:17pm Eastern.
>
> Nothing was lost. No data left the building. We're sorry for the lost time.
>
> If you want the technical write-up, it's [here](#).
>
> — Sam, on the team

### A landing-page paragraph

> A neighborhood already knows things its city doesn't. Which corner the kids walk past. Which buildings lose heat first. Which neighbors check on which neighbors. neighborhoodOS gives organizers a place to write that down — and a few quiet tools to do something with it.

---

## 12. Accessibility

Not a chapter at the back. A constraint we design with from the start.

### Minimums (these are floors, not goals)
- **WCAG 2.2 AA** across the product and marketing site.
- **Color contrast:** 4.5:1 for body, 3:1 for ≥18px or bold.
- **Tap targets:** 44×44px minimum on touch.
- **Keyboard:** every interaction reachable, every focus state visible (2px terracotta ring, 2px offset).
- **Screen readers:** semantic HTML first. ARIA second, and only when semantic HTML can't say it.
- **Motion:** `prefers-reduced-motion` honored everywhere.
- **Forms:** labels are real `<label>` elements. Error messages are programmatically associated.
- **Language:** `lang` attribute set; we ship in English, Spanish, and Haitian Creole at minimum.

### Plain language
We hold ourselves to a 9th-grade reading level on the marketing site and 7th-grade in the product UI. Use [Hemingway](https://hemingwayapp.com) or read it aloud. If your tongue trips, rewrite.

### Names and pronouns
- Always allow a chosen name separate from a legal name.
- Pronoun field is optional and free-text, not a dropdown.
- Don't gender-code icons. A "person" icon is one icon.

### Plus a few we hold ourselves to
- **No autoplay anything.** Audio, video, carousels.
- **No infinite scroll** in the product. Pagination respects working memory.
- **No dark patterns.** No fake urgency, no "are you sure you want to leave us" dialogs, no pre-checked opt-ins.

---

## 13. The short version (for the wallet card)

> **Voice:** Curious neighbor, not a brand.
> **Look:** Paper, terracotta, ochre, ink. A serif that thinks.
> **Rule:** Be specific. Show your work. Use the smallest word that fits.
> **Never:** Leverage, empower, ecosystem, unlock.
> **Always:** Ask first. Name what you don't know.

---

## 14. Maintenance

This document is owned by the design team and edited in the open. Propose changes by PR or by walking up to someone with a reasonable argument. We review quarterly. Big changes get a changelog entry below.

### Changelog
- **v1.0 — Apr 2026.** Initial system. Warm palette, three-family typography, Feynman voice.
